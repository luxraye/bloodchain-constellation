import { Router } from "express";
import * as assetController from "../controllers/asset.controller";
import { requireAuth } from "../middlewares/requireAuth";

const router = Router();
router.use(requireAuth);

router.get("/my-donations", assetController.getMyDonations);
router.get("/", assetController.getAssets);
router.get("/:id/custody", assetController.getCustody);
router.get("/:id", assetController.getAsset);
router.post("/", assetController.createAsset);
router.post("/scan", assetController.scanAsset);

export default router;
