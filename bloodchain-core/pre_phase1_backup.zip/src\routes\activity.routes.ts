import { Router } from "express";
import { requireAuth } from "../middlewares/requireAuth";
import { shiftSync } from "../controllers/activity.controller";

const router = Router();

// GET /activity/shift-sync — Auth required
router.get("/shift-sync", requireAuth, shiftSync);

export default router;
