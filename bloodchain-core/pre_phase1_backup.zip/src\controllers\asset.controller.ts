// ─────────────────────────────────────────────────────
// Bloodchain Core — Asset Controller
// ─────────────────────────────────────────────────────

import { Request, Response, NextFunction } from "express";
import { AssetStatus } from "@prisma/client";
import * as assetService from "../services/asset.service";

// GET /my-donations
export const getMyDonations = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
        const userId = req.auth?.sub;
        if (!userId) { res.status(401).json({ success: false, error: "Unauthorized" }); return; }
        const assets = await assetService.getMyDonations(userId);
        res.json({ success: true, data: assets });
    } catch (e) { next(e); }
};

// GET /
export const getAssets = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
        const status = req.query.status as AssetStatus | undefined;
        const assets = await assetService.getAssets(status);
        res.json({ success: true, data: assets });
    } catch (e) { next(e); }
};

// GET /:id
export const getAsset = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
        const asset = await assetService.getAssetWithCustody(String(req.params.id));
        res.json({ success: true, data: asset });
    } catch (e) { next(e); }
};

// GET /:id/custody
export const getCustody = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
        const asset = await assetService.getAssetWithCustody(String(req.params.id));
        res.json({ success: true, data: asset.custodyEvents, asset: { id: asset.id, bloodType: asset.bloodType, status: asset.status, donor: asset.donor } });
    } catch (e) { next(e); }
};

// POST /
export const createAsset = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
        const { donorId, bloodType, location } = req.body;
        if (!donorId || !bloodType || !location) {
            res.status(400).json({ success: false, error: "Missing required fields: donorId, bloodType, location" });
            return;
        }
        const asset = await assetService.createAsset({ donorId, bloodType, location, actorSupabaseId: req.auth?.sub ?? "" });
        res.status(201).json({ success: true, data: asset });
    } catch (e) { next(e); }
};

// POST /scan
export const scanAsset = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
        const { assetId, newStatus, location, notes } = req.body;
        if (!assetId || !newStatus || !location) {
            res.status(400).json({ success: false, error: "Missing required fields: assetId, newStatus, location" });
            return;
        }
        const asset = await assetService.scanAsset({ assetId, newStatus, location, notes, actorSupabaseId: req.auth?.sub ?? "" });
        res.json({ success: true, data: asset });
    } catch (e) { next(e); }
};
