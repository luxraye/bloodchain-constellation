// ─────────────────────────────────────────────────────
// Bloodchain Core — Admin Controller
// Request/Response handling for admin endpoints
// ─────────────────────────────────────────────────────

import { Request, Response, NextFunction } from "express";
import * as adminService from "../services/admin.service";

// ─── POST /users — Provision User ────────────────────

export const provisionUser = async (
    req: Request,
    res: Response,
    next: NextFunction
): Promise<void> => {
    try {
        const { email, name, role, facilityId } = req.body;

        // Basic validation
        if (!email || !name || !role) {
            res.status(400).json({
                success: false,
                error: "Missing required fields: email, name, role",
            });
            return;
        }

        const user = await adminService.createUser({
            email,
            name,
            role,
            facilityId,
        });

        res.status(201).json({
            success: true,
            data: user,
        });
    } catch (error) {
        next(error);
    }
};

// ─── GET /users — List Users ─────────────────────────

export const listUsers = async (
    req: Request,
    res: Response,
    next: NextFunction
): Promise<void> => {
    try {
        const { role } = req.query;
        const users = await adminService.listUsers(role as string | undefined);

        res.status(200).json({
            success: true,
            count: users.length,
            data: users,
        });
    } catch (error) {
        next(error);
    }
};

// ─── DELETE /users/:id — Remove User ─────────────────

export const deleteUser = async (
    req: Request,
    res: Response,
    next: NextFunction
): Promise<void> => {
    try {
        await adminService.deleteUser(req.params.id as string);
        res.status(200).json({ success: true, message: 'User deleted' });
    } catch (error) {
        next(error);
    }
};

// ─── GET /stats — Dashboard Metrics ──────────────────

export const getStats = async (
    _req: Request,
    res: Response,
    next: NextFunction
): Promise<void> => {
    try {
        const stats = await adminService.getStats();
        res.status(200).json({ success: true, data: stats });
    } catch (error) {
        next(error);
    }
};

// ─── PATCH /users/:id — Update User (trust level, status, etc) ───

export const updateUser = async (
    req: Request,
    res: Response,
    next: NextFunction
): Promise<void> => {
    try {
        const id = req.params.id as string;
        const { trustLevel, verificationDocUrl, status, name, facilityId } = req.body;
        const user = await adminService.updateUser(id, { trustLevel, verificationDocUrl, status, name, facilityId });
        res.status(200).json({ success: true, data: user });
    } catch (error) {
        next(error);
    }
};
