// ─────────────────────────────────────────────────────────────────────────────
// DEPRECATED: Keycloak admin client — replaced by Supabase admin client.
// User creation/deletion now lives in admin.service.ts via supabase.auth.admin.
// This file is kept as a tombstone to avoid import errors during refactor.
// Safe to delete once admin.service.ts is confirmed working.
// ─────────────────────────────────────────────────────────────────────────────

/** @deprecated Use supabaseAdmin from admin.service.ts */
export async function kcCreateUser(_opts: unknown): Promise<string> {
    throw new Error("kcCreateUser is deprecated — use supabase.auth.admin.createUser() instead");
}

/** @deprecated Use supabaseAdmin from admin.service.ts */
export async function kcAssignRole(_userId: string, _role: string): Promise<void> {
    throw new Error("kcAssignRole is deprecated — roles are set via app_metadata in supabase.auth.admin.createUser()");
}

/** @deprecated Use supabaseAdmin from admin.service.ts */
export async function kcDeleteUser(_userId: string): Promise<void> {
    throw new Error("kcDeleteUser is deprecated — use supabase.auth.admin.deleteUser() instead");
}
