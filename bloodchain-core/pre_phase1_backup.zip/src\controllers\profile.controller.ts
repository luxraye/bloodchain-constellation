// ─────────────────────────────────────────────────────
// Bloodchain Core — Profile Controller
// ─────────────────────────────────────────────────────

import { Request, Response, NextFunction } from "express";
import * as profileService from "../services/profile.service";

// GET /profile/me
export const getMyProfile = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
        const sub = req.auth?.sub;
        if (!sub) { res.status(401).json({ success: false, error: "Unauthorized" }); return; }

        // Pass the full auth payload so the service can auto-create missing profiles
        const user = await profileService.getOrCreateProfile(sub, {
            email: req.auth?.email,
            name: (req.auth?.user_metadata as any)?.name || (req.auth?.email as string),
            role: req.auth?.app_metadata?.role,
        });
        res.json({ success: true, data: user });
    } catch (e) { next(e); }
};

// PATCH /profile/me
export const updateMyProfile = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
        const sub = req.auth?.sub;
        if (!sub) { res.status(401).json({ success: false, error: "Unauthorized" }); return; }

        // Auto-create if missing, then update
        await profileService.getOrCreateProfile(sub, {
            email: req.auth?.email,
            name: (req.auth?.user_metadata as any)?.name || (req.auth?.email as string),
            role: req.auth?.app_metadata?.role,
        });

        const { name, bloodType, facilityId, age, gender, region, medicalConditions } = req.body;
        const user = await profileService.updateProfile(sub, { name, bloodType, facilityId, age, gender, region, medicalConditions });
        res.json({ success: true, data: user });
    } catch (e) { next(e); }
};
