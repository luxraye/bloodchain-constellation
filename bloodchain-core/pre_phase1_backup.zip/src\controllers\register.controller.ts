// ─────────────────────────────────────────────────────
// Bloodchain Core — Register Controller (Public)
// ─────────────────────────────────────────────────────

import { Request, Response, NextFunction } from "express";
import * as registerService from "../services/register.service";

// POST /register — Public donor self-signup (Azure only)
export const register = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
        const { email, password, name, bloodType } = req.body;
        if (!email || !password || !name) {
            res.status(400).json({ success: false, error: "Missing required fields: email, password, name" });
            return;
        }
        const result = await registerService.registerDonor({ email, password, name, bloodType });
        res.status(201).json({ success: true, data: { userId: result.user.id, email: result.user.email, name: result.user.name } });
    } catch (e) { next(e); }
};
