// ─────────────────────────────────────────────────────
// Bloodchain Core — Admin Routes
// ─────────────────────────────────────────────────────

import { Router } from "express";
import * as adminController from "../controllers/admin.controller";
import { requireAuth } from "../middlewares/requireAuth";

const router = Router();

// All admin routes require a valid Keycloak JWT
router.use(requireAuth);

// POST /api/v1/admin/users — Provision a new user
router.post("/users", adminController.provisionUser);

// GET  /api/v1/admin/users — List all users (optional ?role= filter)
router.get("/users", adminController.listUsers);

// DELETE /api/v1/admin/users/:id — Remove a user (DB + Keycloak)
router.delete("/users/:id", adminController.deleteUser);

// PATCH  /api/v1/admin/users/:id — Update user (trust level, status, etc)
router.patch("/users/:id", adminController.updateUser);

// GET  /api/v1/admin/stats — Dashboard metrics
router.get("/stats", adminController.getStats);

export default router;
