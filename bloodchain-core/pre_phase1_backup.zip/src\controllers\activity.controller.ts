import { Request, Response, NextFunction } from "express";
import * as activityService from "../services/activity.service";

/**
 * GET /activity/shift-sync
 * Returns today's ActionLog entries for the requesting user's role + facility.
 */
export const shiftSync = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
        const user = (req as any).user;
        const role: string = user?.role ?? "";
        const facility: string = user?.facilityId ?? user?.facility ?? "";

        const logs = await activityService.getShiftSync(role, facility);

        res.json({ success: true, data: logs });
    } catch (e) {
        next(e);
    }
};
